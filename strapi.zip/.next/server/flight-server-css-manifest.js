self.__RSC_CSS_MANIFEST={
  "cssImports": {
    "C:\\Users\\lab\\Desktop\\Next\\strapi\\app\\layout.js": [
      "C:\\Users\\lab\\Desktop\\Next\\strapi\\node_modules\\next\\font\\google\\target.css?{\"path\":\"app\\\\layout.js\",\"import\":\"Inter\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"inter\"}",
      "C:\\Users\\lab\\Desktop\\Next\\strapi\\app\\globals.css"
    ]
  },
  "cssModules": {
    "C:\\Users\\lab\\Desktop\\Next\\strapi\\app\\films\\page": [
      "C:\\Users\\lab\\Desktop\\Next\\strapi\\app\\globals.css",
      "C:\\Users\\lab\\Desktop\\Next\\strapi\\node_modules\\next\\font\\google\\target.css?{\"path\":\"app\\\\layout.js\",\"import\":\"Inter\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"inter\"}"
    ],
    "C:\\Users\\lab\\Desktop\\Next\\strapi\\app\\page": [
      "C:\\Users\\lab\\Desktop\\Next\\strapi\\app\\globals.css",
      "C:\\Users\\lab\\Desktop\\Next\\strapi\\node_modules\\next\\font\\google\\target.css?{\"path\":\"app\\\\layout.js\",\"import\":\"Inter\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"inter\"}"
    ]
  }
}